# Realtools Extension

Mini version of Realtools for Chromium-based and Firefox-based browsers.

# Links

* [Chrome Web Store page](https://realtools.shay.cat/chrome)
* [addons.mozilla.org page](https://realtools.shay.cat/firefox)
* [Realtools' main site](https://realtools.shay.cat)

# Demonstration

[Demonstration GIF](https://i.imgur.com/X6BMNj5.gif)

A demonstration on Firefox 93
